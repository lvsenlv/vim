#!/bin/sh
rm -f ~/.vimrc
rm -rf ~/.vim
mv -f ~/.vimrc_old ~/.vimrc
mv -f ~/.vim_old ~/.vim
